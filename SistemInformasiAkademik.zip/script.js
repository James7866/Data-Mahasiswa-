
let mahasiswa = JSON.parse(localStorage.getItem("mahasiswa")) || [];

document.getElementById("submitBtn").addEventListener("click", () => {
    const nama = document.getElementById("nama").value.trim();
    const nim = document.getElementById("nim").value.trim();
    const jurusan = document.getElementById("jurusan").value.trim();

    if (!nama || !nim || !jurusan) {
        alert("Semua field harus diisi!");
        return;
    }

    if (mahasiswa.some(m => m.nim === nim)) {
        alert("NIM sudah terdaftar!");
        return;
    }

    mahasiswa.push({ nama, nim, jurusan });
    simpanData();
    updateTabel();
    resetForm();
});

function simpanData() {
    localStorage.setItem("mahasiswa", JSON.stringify(mahasiswa));
}

function updateTabel(data = mahasiswa) {
    const tbody = document.querySelector("#dataTable tbody");
    tbody.innerHTML = "";

    data.forEach((m, index) => {
        const row = `<tr>
            <td>${m.nama}</td>
            <td>${m.nim}</td>
            <td>${m.jurusan}</td>
            <td>
                <button onclick="editData(${index})">Edit</button>
                <button onclick="hapusData(${index})">Hapus</button>
            </td>
        </tr>`;
        tbody.innerHTML += row;
    });
}

function resetForm() {
    document.getElementById("nama").value = "";
    document.getElementById("nim").value = "";
    document.getElementById("jurusan").value = "";
}

function cariData() {
    const keyword = document.getElementById("searchInput").value.trim().toLowerCase();
    const hasil = mahasiswa.filter(m => m.nama.toLowerCase().includes(keyword) || m.nim.includes(keyword));
    updateTabel(hasil);
}

function hapusData(index = null) {
    if (index === null) {
        const keyword = document.getElementById("searchInput").value.trim().toLowerCase();
        mahasiswa = mahasiswa.filter(m => !(m.nama.toLowerCase().includes(keyword) || m.nim.includes(keyword)));
    } else {
        mahasiswa.splice(index, 1);
    }
    simpanData();
    updateTabel();
}

function urutkanData(field) {
    mahasiswa.sort((a, b) => a[field].localeCompare(b[field]));
    updateTabel();
}

function editData(index) {
    const m = mahasiswa[index];
    document.getElementById("nama").value = m.nama;
    document.getElementById("nim").value = m.nim;
    document.getElementById("jurusan").value = m.jurusan;
    hapusData(index);
}

window.onload = updateTabel;
